package core.java;

public class Variable {
	int a=10;
	public static void main(String[]args) {
	   int a=20;
	    System.out.println(a); 

	}
	
}

