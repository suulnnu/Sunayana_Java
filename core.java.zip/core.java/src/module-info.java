/**
 * 
 */
/**
 * 
 */
module core.java {
}